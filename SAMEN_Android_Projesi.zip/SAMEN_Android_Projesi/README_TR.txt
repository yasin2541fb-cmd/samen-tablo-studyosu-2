SAMEN TABLO STÜDYOSU — ANDROID STUDIO PROJESİ

Bu ZIP, APK değil; Android Studio ile APK oluşturmak için kaynak proje içerir.

APK oluşturma:
1. ZIP'i bilgisayarında bir klasöre çıkar.
2. Android Studio'yu aç.
3. Open seçeneğiyle SAMEN_Android_Projesi klasörünü seç.
4. Gradle senkronizasyonunun bitmesini bekle.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) seç.
6. APK genellikle app/build/outputs/apk/debug/app-debug.apk yoluna çıkar.
7. APK'yı telefonuna gönderip aç. Android, bilinmeyen kaynaktan yüklemeye izin vermeni isteyebilir.

Gereksinimler:
- Android Studio güncel sürüm
- JDK / Gradle araçlarının Android Studio tarafından kurulması
- İlk senkronizasyon sırasında internet bağlantısı

Notlar:
- Bu proje bu ortamda derlenmedi veya gerçek cihazda test edilmedi.
- Uygulama içindeki tablolar WebView yerel depolamasında tutulur. Uygulama verilerini temizlemek kayıtları silebilir.
- Üretim dağıtımı için imzalı release APK/AAB, uygulama ikonu ve cihaz testleri önerilir.
